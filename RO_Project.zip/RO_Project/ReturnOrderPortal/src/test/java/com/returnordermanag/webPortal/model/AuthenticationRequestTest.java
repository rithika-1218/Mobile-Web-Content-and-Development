package com.returnordermanag.webPortal.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.returnordermanag.webPortal.model.AuthenticationRequest;

public class AuthenticationRequestTest {

	AuthenticationRequest authenticationRequest = new AuthenticationRequest();
	
	
	
	@Test
	void testGetUserName() {
		authenticationRequest.setUsername("Harish");
		assertEquals("Harish", authenticationRequest.getUsername());
	}
	
	@Test
	void testSetUserName() {
		authenticationRequest.setUsername("Harish");
		assertEquals("Harish", authenticationRequest.getUsername());
	}
	@Test
	void testGetPassword() {
		authenticationRequest.setPassword("Harish");
		assertEquals("Harish", authenticationRequest.getPassword());
	}
	
	@Test
	void testSetPassword() {
		authenticationRequest.setPassword("Harish");
		assertEquals("Harish", authenticationRequest.getPassword());
	}
	
	@Test
	void testConstructor() {
		AuthenticationRequest ar = new AuthenticationRequest("Harish", "Harish");
		assertEquals("Harish", ar.getUsername());
		assertEquals("Harish", ar.getPassword());
	}
}