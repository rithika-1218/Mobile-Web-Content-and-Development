package com.returnordermanag.webPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReturnOrderPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
