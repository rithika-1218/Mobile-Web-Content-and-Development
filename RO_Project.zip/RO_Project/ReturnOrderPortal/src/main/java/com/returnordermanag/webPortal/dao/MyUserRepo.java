package com.returnordermanag.webPortal.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.returnordermanag.webPortal.model.MyUser;

/**
 * This is an interface
 * for MyUser Repository
 * which extends JpaRepository
 */
@Repository
public interface MyUserRepo extends JpaRepository<MyUser, Integer>{
	MyUser findByUserName(String name);
}


