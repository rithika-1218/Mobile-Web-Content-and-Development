package com.returnordermanag.webPortal.controller;

import java.util.NoSuchElementException;

import org.hibernate.internal.build.AllowSysOut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.returnordermanag.webPortal.client.AuthenticationFeignClient;
import com.returnordermanag.webPortal.dao.MyUserRepo;
import com.returnordermanag.webPortal.dao.UserAuthenticationRepository;
import com.returnordermanag.webPortal.model.AuthenticationRequest;
import com.returnordermanag.webPortal.model.AuthenticationResponse;
import com.returnordermanag.webPortal.model.MyUser;
import com.returnordermanag.webPortal.model.UserDetails;
import com.returnordermanag.webPortal.service.LoginService;

/**
 * This is a 
 * Controller class 
 * communicates with ComponentProcessing microservice
 */
@Controller
public class HomeController {

	static Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired
	private LoginService loginService;

	@Autowired
	private AuthenticationRequest authenticationRequest;

	@Autowired
	private AuthenticationResponse authenticationResponse;

	@Autowired
	private AuthenticationFeignClient authenticationFeignClient;
	
	@Autowired
	private UserAuthenticationRepository userAuthenticationRepo;
	
	@Autowired
	private MyUserRepo repo;
	
	/**
	 * This is a method
	 * @return login page.
	 */
	@RequestMapping("/")
	public String open() {

		return "login.jsp";
	}

	/**
	 * This is a method
	 * @param username
	 * @param password
	 * @param map
	 * @return home page or login page.
	 */
	@RequestMapping("/login")
	public String login(@RequestParam("username") String username, @RequestParam("password") String password, Model map) {

		logger.info("Handling /login request");
	
		MyUser myuser = repo.findByUserName(username);
		
		
		
		if(myuser == null) {
			map.addAttribute("name_error", "Bad credentials");
			return "login.jsp";
		}
		
		
		
		else if (!password.equals(myuser.getPassword())) {
			map.addAttribute("name_error", "Incorrect password");
			return "login.jsp";
		}
		else{
			
		authenticationRequest.setUsername(username);
		authenticationRequest.setPassword(password);
			
	
		authenticationResponse = authenticationFeignClient.createAuthenticationToken(authenticationRequest);

		String jwtToken = authenticationResponse.getJwtToken();
		boolean isValid = authenticationResponse.getValid();
		int userID = 101; 

		loginService.createUser(userID, authenticationResponse.getUsername(), authenticationResponse.getPassword(), jwtToken, isValid);
		
		boolean valid = authenticationResponse.getValid();
		
		
		if (valid)
			return "home.jsp";
		
		return "login.jsp";
		
	}
	
		
	}
	
	
	
	/**
	 * This is a method
	 * @return home page
	 */
	@RequestMapping("/home")
	public String home() {
		
		return "home.jsp";
	}
		
	
	
	
	@RequestMapping("/logout")
	public String logout() {
		
		try {
		UserDetails user=  userAuthenticationRepo.findById(101).get();
		
		user.setValid(false);
		user.setJwtToken(null);
		userAuthenticationRepo.save(user);
		
		}
		catch(NoSuchElementException e) {
			return "redirect:/";
			
		}
		
		
		return "redirect:/";
		
	}
	
	
	
}
	

