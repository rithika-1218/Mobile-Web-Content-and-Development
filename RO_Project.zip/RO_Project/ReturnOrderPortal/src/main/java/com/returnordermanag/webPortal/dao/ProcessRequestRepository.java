package com.returnordermanag.webPortal.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.returnordermanag.webPortal.model.ProcessRequest;

/**
 * This is an interface
 * for ProcessRequest Repository
 * which extends JpaRepository
 */
@Repository
public interface ProcessRequestRepository extends JpaRepository<ProcessRequest, Integer> {

	List<ProcessRequest>  findAllByUsername(String username);
	
}
