package com.returnordermanag.webPortal.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.returnordermanag.webPortal.model.AuthenticationRequest;
import com.returnordermanag.webPortal.model.AuthenticationResponse;

/**
 * This is a FeignClient interface
 * used to communicate with
 * Authorization microservice.
 */
@FeignClient(name = "authenticationFeignClient", url = "localhost:8084/")
public interface AuthenticationFeignClient {

	/**
	 * To create authentication token
	 * @param authenticationRequest
	 * @return AuthenticationResponse
	 */
	@PostMapping("/login")
	public AuthenticationResponse createAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest);


}
