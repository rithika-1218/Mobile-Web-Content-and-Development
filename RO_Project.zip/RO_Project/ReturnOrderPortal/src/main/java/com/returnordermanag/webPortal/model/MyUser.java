package com.returnordermanag.webPortal.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

	@Entity
	@Table(name = "myuser_details")
	public class MyUser {
		@Id
		private int userID;
		private String userName;
		private String password;
		public int getUserID() {
			return userID;
		}
		public void setUserID(int userID) {
			this.userID = userID;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public MyUser(int userID, String userName, String password) {
			super();
			this.userID = userID;
			this.userName = userName;
			this.password = password;
		}
		
		public MyUser() {
			super();
		}
		@Override
		public String toString() {
			return "MyUser [userID=" + userID + ", userName=" + userName + ", password=" + password + "]";
		}
		
}
