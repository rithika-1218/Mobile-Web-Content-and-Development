package com.returnordermanag.webPortal.model;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Component
public class AuthenticationResponse {
	private int userID;
	private String jwtToken;
	private Boolean valid;
	private String username;
	private String password;
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getJwtToken() {
		return jwtToken;
	}
	public void setJwtToken(String jwtToken) {
		this.jwtToken = jwtToken;
	}
	public Boolean getValid() {
		return valid;
	}
	public void setValid(Boolean valid) {
		this.valid = valid;
	}

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public AuthenticationResponse(int userID, String jwtToken, Boolean valid, String username, String password) {
		super();
		this.userID = userID;
		this.jwtToken = jwtToken;
		this.valid = valid;
		this.username = username;
		this.password = password;
	}
	
	public AuthenticationResponse() {
		super();
	}

	
}
