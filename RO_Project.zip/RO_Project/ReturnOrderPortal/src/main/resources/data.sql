--insert into MYUSER values  (1,'Mrunal','Mrunal'), (2,'Abhishek','Abhishek'), (3,'Harivivek','Harivivek'), (4,'Satyam','Satyam');

insert into myuser_details values  (1,'Vidhula','Vidhula');
insert into myuser_details values  (2,'Harish','Harish');
insert into myuser_details values  (3,'Rithika','Rithika');
insert into myuser_details values  (4,'Pravalika','Pravalika');
insert into myuser_details values  (5,'Sri','Sri');




