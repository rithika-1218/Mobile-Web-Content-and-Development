package com.returnordermanag.packageDeliveryModule.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.returnordermanag.packageDeliveryModule.dao.ChargesRepo;
import com.returnordermanag.packageDeliveryModule.model.Charges;

@Service
public class PackagingAndDeliveryService {

	@Autowired
	ChargesRepo repo;

	static Logger logger = LoggerFactory.getLogger(PackagingAndDeliveryService.class);

	private long packagingAndDeliveryCost = 0;

	public long getPackingAndDeliveryCharge(String componentType, int count) {

		logger.info("Calculating packaging and delivery charges");
		Charges charge = repo.findById(1).get();

		if (componentType.equalsIgnoreCase("integral")) {
			packagingAndDeliveryCost = charge.getProtectiveSheath() + charge.getIntegralPackaging()
					+ charge.getIntegralDelivery();

			return (packagingAndDeliveryCost * count);
		}

		else if (componentType.equalsIgnoreCase("accessory")) {
			packagingAndDeliveryCost = charge.getProtectiveSheath() + charge.getAccesoryPackaging()
					+ charge.getAccessoryDelivery();
			return (packagingAndDeliveryCost * count);
			
		}

		return packagingAndDeliveryCost;
	}
}
