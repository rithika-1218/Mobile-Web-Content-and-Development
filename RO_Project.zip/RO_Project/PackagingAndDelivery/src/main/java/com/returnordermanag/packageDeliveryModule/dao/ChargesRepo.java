package com.returnordermanag.packageDeliveryModule.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.returnordermanag.packageDeliveryModule.model.Charges;

/**
 * This is an interface
 * for Charges Repository
 * which extends JpaRepository
 */
public interface ChargesRepo extends JpaRepository<Charges,Integer> {

}
