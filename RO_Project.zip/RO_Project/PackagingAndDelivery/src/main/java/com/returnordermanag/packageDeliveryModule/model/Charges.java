package com.returnordermanag.packageDeliveryModule.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Charges {

	@Id
	int id;
	int protectiveSheath;
	int integralPackaging;
	int accesoryPackaging;
	int integralDelivery;
	int accessoryDelivery;

	@Override
	public String toString() {
		return "Charges [id=" + id + ", protectiveSheath=" + protectiveSheath + ", integralPackaging="
				+ integralPackaging + ", accesoryPackaging=" + accesoryPackaging + ", integralDelivery="
				+ integralDelivery + ", accessoryDelivery=" + accessoryDelivery + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getProtectiveSheath() {
		return protectiveSheath;
	}
	public void setProtectiveSheath(int protectiveSheath) {
		this.protectiveSheath = protectiveSheath;
	}
	public int getIntegralPackaging() {
		return integralPackaging;
	}
	public void setIntegralPackaging(int integralPackaging) {
		this.integralPackaging = integralPackaging;
	}
	public int getAccesoryPackaging() {
		return accesoryPackaging;
	}
	public void setAccesoryPackaging(int accesoryPackaging) {
		this.accesoryPackaging = accesoryPackaging;
	}
	public int getIntegralDelivery() {
		return integralDelivery;
	}
	public void setIntegralDelivery(int integralDelivery) {
		this.integralDelivery = integralDelivery;
	}
	public int getAccessoryDelivery() {
		return accessoryDelivery;
	}
	public void setAccessoryDelivery(int accessoryDelivery) {
		this.accessoryDelivery = accessoryDelivery;
	}

}
