insert into charges values (1,50,100,50,200,100);
