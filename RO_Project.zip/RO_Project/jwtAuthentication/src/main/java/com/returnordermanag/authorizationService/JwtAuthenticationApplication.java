package com.returnordermanag.authorizationService;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.returnordermanag.authorizationService.Repository.UserRepository;
import com.returnordermanag.authorizationService.model.MyUser; 

/**
 * This is a SpringBoot Application
 */
@SpringBootApplication
public class JwtAuthenticationApplication {
	
	static Logger logger = LoggerFactory.getLogger(JwtAuthenticationApplication.class);
	
	@Autowired
    private UserRepository repository;

    @PostConstruct
    public void initUsers() {
        List<MyUser> users = Stream.of(
               new MyUser("1","Vidhula","$2a$10$fLF84i9PNEscJthAuwMlzuzJfIPQmOJx0sWvHGbpo3jPdFcXPEkOm"),
               new MyUser("2","Harish","$2a$10$qA4GQgzdX9h96JQEw6loVunZuWzzrlp/EVk3PR0p2ML2XyN0840F6"),
               new MyUser("3","Rithika","$2a$10$6BZr97.JAvUP5gTPkctOH.eUeeJz3hQa6fnbtRPVWtZjWiJ1iWtJS"),
               new MyUser("4","Pravalika","$2a$10$2dv/MBf2ZGcJQMT7XA7RkuOK3rBB7BgZhdnX6vfyelgWdean2drcy"),
               new MyUser("5","Sri","$2a$10$nwjjJXNtM5X7ZpKUJ4g1HO54qu/WDMhAN8/5vWLWxEoKgU.T8E6rm")
        ).collect(Collectors.toList());
        repository.saveAll(users);
    }

    /**
     * This is the main method where 
	 * execution of the code begins.
     * @param args
     */
	public static void main(String[] args) {
		SpringApplication.run(JwtAuthenticationApplication.class, args);
		logger.info("Authentication module started successfully");
	}

}
