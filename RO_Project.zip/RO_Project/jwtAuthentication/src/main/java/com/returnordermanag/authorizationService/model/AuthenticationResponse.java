package com.returnordermanag.authorizationService.model;

public class AuthenticationResponse {

	private String jwtToken;
	private Boolean valid;
	private String username;
	private String password;
	public String getJwtToken() {
		return jwtToken;
	}
	public void setJwtToken(String jwtToken) {
		this.jwtToken = jwtToken;
	}
	public Boolean getValid() {
		return valid;
	}
	public void setValid(Boolean valid) {
		this.valid = valid;
	}

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public AuthenticationResponse(String jwtToken, Boolean valid, String username, String password) {
		super();
		this.jwtToken = jwtToken;
		this.valid = valid;
		this.username = username;
		this.password = password;
	}
	public AuthenticationResponse() {
		super();
	}

	
	
}
