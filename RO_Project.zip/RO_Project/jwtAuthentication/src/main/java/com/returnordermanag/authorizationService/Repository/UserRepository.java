package com.returnordermanag.authorizationService.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.returnordermanag.authorizationService.model.MyUser;

/**
 * This is an interface
 * for  User Repository
 * which extends JpaRepository
 */
public interface UserRepository extends JpaRepository<MyUser,String > {

	public MyUser findByUsername(String username);

	

}
