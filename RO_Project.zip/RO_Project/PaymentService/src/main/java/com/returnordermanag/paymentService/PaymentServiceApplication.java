package com.returnordermanag.paymentService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * This is a SpringBoot Application, 
 * using JPA Repositories and FeignClient
 * for communication with other microservices
 */

@SpringBootApplication
@EnableFeignClients
public class PaymentServiceApplication {

	static Logger logger = LoggerFactory.getLogger(PaymentServiceApplication.class);
	
	/**
	 * This is the main method where 
	 * execution of the code begins.
	 * @param args
	 */
	
	public static void main(String[] args) {
		SpringApplication.run(PaymentServiceApplication.class, args);
		logger.info("Payment Service Application started successfully");
	}

}
