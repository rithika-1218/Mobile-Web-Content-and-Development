package com.returnordermanag.componentProcessModule.client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * This is a FeignClient interface
 * used to communicate with
 * PaymentService microservice.
 */

@FeignClient(name="paymentFeignClient", url="localhost:8082/card/")
public interface PaymentFeignClient {
	
	/**
	 * To get current balance
	 * @param cardNumber
	 * @param charge
	 * @return double
	 */
	@GetMapping(value = "/{cardNumber}/{charge}")
	double getCurrentBalance(@PathVariable long cardNumber,@PathVariable double charge);
}
