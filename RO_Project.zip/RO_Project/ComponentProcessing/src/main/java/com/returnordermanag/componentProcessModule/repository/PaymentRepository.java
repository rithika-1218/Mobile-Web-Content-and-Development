package com.returnordermanag.componentProcessModule.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.returnordermanag.componentProcessModule.model.Payment;

/**
 * This is an interface
 * for Payment Repository
 * which extends JpaRepository
 */
@Repository
public interface PaymentRepository extends JpaRepository<Payment, Integer>{

}
