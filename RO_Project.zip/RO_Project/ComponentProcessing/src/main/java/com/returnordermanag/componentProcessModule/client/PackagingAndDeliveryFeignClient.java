package com.returnordermanag.componentProcessModule.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * This is a FeignClient interface
 * used to communicate with
 * PackageAndDelivery microservice.
 */
@FeignClient(name="packagingAndDeliveryFeignClient", url="localhost:8083/PackagingAndDeliveryCharge/")
public interface PackagingAndDeliveryFeignClient {
	
	/**
	 * To get packaging and delivery charge
	 * @param componentType
	 * @param count
	 * @return long
	 */
	@GetMapping(value = "/{componentType}/{count}")
	long getPackagingAndDeliveryCharge(@PathVariable("componentType") String componentType, @PathVariable("count") int count);
}
