package com.returnordermanag.componentProcessModule;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;


/**
 * This is a SpringBoot Application, 
 * using JPA Repositories and FeignClient
 * for communication with other microservices
 */

@SpringBootApplication
@EnableFeignClients
public class ComponentProcessingMicroserviceApplication {
	
	static Logger logger = LoggerFactory.getLogger(ComponentProcessingMicroserviceApplication.class);
	
	/**
	 * This is the main method where 
	 * execution of the code begins.
	 * @param args
	 */
	
	public static void main(String[] args) {
		SpringApplication.run(ComponentProcessingMicroserviceApplication.class, args);
		logger.info("Component Processing Module started successfully");
	}

}
