package com.returnordermanag.componentProcessModule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComponentProcessingMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
