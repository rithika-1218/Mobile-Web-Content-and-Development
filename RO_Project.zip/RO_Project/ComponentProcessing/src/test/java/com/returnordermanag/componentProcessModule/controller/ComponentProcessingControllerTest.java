package com.returnordermanag.componentProcessModule.controller;

import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import com.returnordermanag.componentProcessModule.controller.ComponentProcessingController;

@WebMvcTest(ComponentProcessingController.class)
public class ComponentProcessingControllerTest {

}
